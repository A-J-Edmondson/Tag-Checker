﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HtmlTagChecker
{
    class Program
    {
        static void Main(string[] args)
        {
            Program program = new Program();
            while (true)
            {
                Console.Write("Enter string: ");
                string inputString = Console.ReadLine();
                Console.WriteLine(program.htmlChecker(inputString));
                Console.WriteLine("");
            }
        }

        public string htmlChecker(string checkString)
        {
            List<char> openTagArray = new List<char>();
            char[] stringList = checkString.ToCharArray();
            for (int i = 0; i < stringList.Length; i++)
            {
                if (stringList[i] == '<' && (i < stringList.Length - 2))
                {
                    if (char.ToUpper(stringList[i+1]) == stringList[i+1] && stringList[i+2] == '>')
                    {
                        char current = stringList[i+1];
                        openTagArray.Add(current);
                    }
                    else if ((i < stringList.Length - 3) && stringList[i+1] == '/' && char.ToUpper(stringList[i+2]) == stringList[i+2] && stringList[i+3] == '>')
                    {
                        if (openTagArray.Count == 0)
                        {
                            return String.Format("Expected # found </{0}>", stringList[i + 2]);
                        }
                        for (int j=0; j < openTagArray.Count; j++)
                        {
                            if (openTagArray[openTagArray.Count-1] == stringList[i+2])
                            {
                                openTagArray.RemoveAt(openTagArray.Count-1);
                            }
                            else
                            {
                                return String.Format("Expected </{0}> found </{1}>", openTagArray[openTagArray.Count - 1], stringList[i + 2]);
                            }
                        }
                    }
                }
            }
            if (openTagArray.Count == 0)
            {
                return "Correctly tagged paragraph";
            }
            else
            {
                char lastStr = openTagArray[openTagArray.Count-1];
                return String.Format("Expected </{0}> found #", lastStr);
            }
        }
    }
}
